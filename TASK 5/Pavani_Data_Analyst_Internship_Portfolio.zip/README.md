# Data Analyst Internship Portfolio

## About Me
Aspiring Data Analyst with hands-on experience in Python, SQL, Power BI, EDA, Dashboarding and Statistical Analysis.

## Internship Tasks
- Task 1: Data Wrangling & Cleaning
- Task 2: EDA & Business Intelligence
- Task 3: Deep-Dive Analysis & Dashboarding
- Task 4: Data Storytelling & Statistical Validation
- Task 5: Portfolio Finalization

## Skills
Python, Pandas, NumPy, SQL, Power BI, GitHub
